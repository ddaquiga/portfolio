#include "graph_test.h"

int main() {
  GraphTest test;
  test.run_tests();

  return 0;
}