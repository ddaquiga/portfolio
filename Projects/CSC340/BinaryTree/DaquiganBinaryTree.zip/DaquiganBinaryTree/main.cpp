#include "binary_tree_test.h"

int main() {
  BinaryTreeTest test;
  test.run_tests();

  return 0;
}