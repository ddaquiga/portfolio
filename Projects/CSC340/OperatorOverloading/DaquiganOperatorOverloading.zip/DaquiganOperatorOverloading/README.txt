To compile, run the makefile with the command:
	make

To run the executable, use this command:
	./driver