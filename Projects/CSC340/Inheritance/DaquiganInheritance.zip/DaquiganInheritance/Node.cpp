/*****************************************
 * Darrel Daquigan
 * 915744913
 * darreldaquigan@sfsu.edu
 * Cygwin64 2.2.1
 *****************************************/

#include "node.h"


Node::Node( int newValue )
{
  next = NULL;
  value = newValue;
}
