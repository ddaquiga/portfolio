/*****************************************
 * Darrel Daquigan
 * 915744913
 * darreldaquigan@sfsu.edu
 * Cygwin64 2.2.1
 *****************************************/

#ifndef NO_OP_ITEM
#define NO_OP_ITEM

#include "map_item.h"

class NoOpItem : public MapItem
{
public:
  NoOpItem();
  virtual ~NoOpItem();
  void tick();
};

#endif