# Disc Seek Simulator

compile diskSim.cpp:

	g++ -c diskSim.cpp

	g++ -o diskSim diskSim.o

run diskSim.exe:

	./diskSim

In this project, I study the average seek time, Sd(Q), for the Quantum Atlas III disk in regards to the disk queue length, Q.