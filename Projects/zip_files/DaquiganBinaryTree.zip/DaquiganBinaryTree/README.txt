# Binary Tree

To compile, run the makefile with the command:

	make

To run the executable, use this command:

	./driver

In this project, I created the node and tree classes to test against the binary_tree_test class.