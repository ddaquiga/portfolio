'use strict';

(function () {

  function begin(){

    os._internals.ps._whateverName_();





  }


  












}) ();