# Operator-Overloading

To compile, run the makefile with the command:

	make

To run the executable, use this command:

	./driver

In this project, I needed to create map and map_item classes which would pass the tests in the op_overloading_test class.