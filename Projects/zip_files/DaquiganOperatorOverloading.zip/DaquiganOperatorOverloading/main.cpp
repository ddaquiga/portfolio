#include "op_overloading_test.h"

int main() {
  OperatorOverloadingTest test;
  test.run_tests();

  return 0;
}