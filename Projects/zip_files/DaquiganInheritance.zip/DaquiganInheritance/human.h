#ifndef HUMAN
#define HUMAN

#include "race.h"

using namespace std;

class Human : public Race{
public:
	Human();
};

#endif