# Inheritance

To compile, run the makefile with the command:

	make

To run the executable, use this command:

	./driver

In this project, I create factory, residential, and no_op classes to extend the map_item class. To do this I also created the node and queue classes. All these classes were tested against the inheritance_test class.