/*****************************************
 * Darrel Daquigan
 * 915744913
 * darreldaquigan@sfsu.edu
 * Cygwin64 2.2.1
 *****************************************/

#include "no_op_item.h"

NoOpItem::NoOpItem(){}
NoOpItem::~NoOpItem(){}
void NoOpItem::tick(){}