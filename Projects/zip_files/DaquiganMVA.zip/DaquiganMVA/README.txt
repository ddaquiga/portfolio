# Interactive/Batch Server System Model Analysis

compile MVA.cpp:

	g++ -c MVA.cpp
	g++ -o MVA MVA.o

run MVA.exe:

	./MVA

In this project I created a program that uses a mean value analysis to give performance statistics of both interactive and batch server systems.