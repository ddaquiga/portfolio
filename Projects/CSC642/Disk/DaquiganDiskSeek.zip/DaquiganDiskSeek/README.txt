compile diskSim.cpp:
	g++ -c diskSim.cpp
	g++ -o diskSim diskSim.o

run diskSim.exe
	./diskSim