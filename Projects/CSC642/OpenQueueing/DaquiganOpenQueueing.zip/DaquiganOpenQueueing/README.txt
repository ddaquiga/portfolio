compile openQueueing.cpp:
	g++ -c openQueueing.cpp
	g++ -o openQueueing openQueueing.o

run openQueueing.exe
	./openQueueing