# Graph

To compile, run the makefile with the command:

	make

To run the executable, use this command:

	./driver

In this project, I create the vertex and graph classes to test against the graph_test class.